mysql = {
    'database': 'school.db'
}